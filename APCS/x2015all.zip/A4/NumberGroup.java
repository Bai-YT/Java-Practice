// Part (a)

public interface NumberGroup
{
  boolean contains(int x);
}
